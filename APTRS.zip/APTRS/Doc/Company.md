# Company

The company option allows you to create a new customer company for which you are doing penetration testing. The company will be required while create a project. Once you install the APTRS you can see a demo company created to get an idea of how it works.

## Company List

If you acess the `http://127.0.0.1:8000/company/` you are see all the companines create in the table. You can either delete, edit or add new company from the same page.

![ViewCompany](image/ViewCompany.png)

## Edit/Add Company 

Once you click on the edit/add button in the above table. You can edit/add the company details like Logo, Name and address. The logo will be used on the cove page of the report. As of now the address will not be displayed in the report will be fixed in the later version.

![EditCompany](image/Edit-Company.png)
