# Settings

The setting option allow you are create a new user. The option allows you to create a user and will be parart of the penetration testing process. By default all the user user added will be considerd as part of the project and will be shown in the report.

The same implice on the customer as well. All the customer add for any company will be considered as part of the project for that customer.


## User List

If you acess the `http://127.0.0.1:8000/accounts/setting` you are see all the users in the table. You can either delete, edit or add new new from the same page.

![View User](image/View%20User.png)

## Edit/Add User 

Once you click on the edit/add button in the above table. You can edit/add the User profile image, First Name, Password, Username, Company Name, Email, Number etc.

![Edit User](image/Edit%20User.png)

![Add User](image/Add%20User.png)

!> As of now You cannot change the password after creating user. The users will be considered as internal user with login access it should have same company name.
