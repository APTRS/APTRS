# Report Template

The report is created using HTML to PDF method. In you want to modify the Report template you need to edit the HTML files. Yuo can see all the HTML files related to Report from [here](https://github.com/Anof-cyber/APTRS/tree/main/templates/Report).

The application create Cover page separately and use `cove.html` for the same. You can edit it hover you want.

Next we have `toc.xml` that is used for table of content. You can edit the same if you want. 

!>The tool will use all H1 tags in the `Report.html` page to show them in Table of content.

The `Report.html` is where all the HTML code is save to generate the report. You can have a look at it and edit accordingly.