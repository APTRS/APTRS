# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 0.x.x   | :white_check_mark: |
| 1.x.x   | :white_check_mark: |

## Reporting a Vulnerability

Report any vulnerability or security issues to kalalsourav20@gmail.com or in [issues](https://github.com/Anof-cyber/APTRS/issues)
